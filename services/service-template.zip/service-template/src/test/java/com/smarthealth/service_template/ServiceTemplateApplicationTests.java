package com.smarthealth.service_template;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
